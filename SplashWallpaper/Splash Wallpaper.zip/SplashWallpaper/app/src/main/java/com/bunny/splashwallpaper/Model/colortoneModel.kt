package com.bunny.splashwallpaper.Model

data class colortoneModel(
    val id:String="",
    val link:String="",
    val color:String=""


)
