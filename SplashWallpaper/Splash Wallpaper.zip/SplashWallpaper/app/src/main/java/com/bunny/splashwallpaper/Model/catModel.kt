package com.bunny.splashwallpaper.Model

data class catModel(
    val name:String="",
    val id:String="",
    val link:String="",

)
