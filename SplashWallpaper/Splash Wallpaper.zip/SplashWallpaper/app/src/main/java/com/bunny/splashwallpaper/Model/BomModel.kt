package com.bunny.splashwallpaper.Model

data class BomModel(
    val id: String = "",
    val link: String = ""

)
